   // Crie 3 objetos da classe Aluno.
//let aluno1 = new Aluno('2º ano A', 'Anthony', 'Machado', new Date("2005-12-23"), '2022uagduyad', 'https://drive.google.com/file/d/1eynFc-CNmGcYZb6b5r5QxWs_DINsmkFT');
//let aluno2 = new Aluno('2º ano A', 'Catarina', 'Silva', 16, '2022abuble', 'https://drive.google.com/file/d/1tCJ1hVCp7445_lj-Dj4LZ0yOaTAfxwA2');
//let aluno3 = new Aluno('2º ano A', 'Wytalo', 'Santos', 17, '2022ahtyht', 'https://drive.google.com/file/d/1veLv6ByeW7wDjrojoeoYjeE-vIprjSLz');
//let aluno4 = new Aluno('2º ano A', 'Vitor', 'Santos', 16, '2022htyhgd', 'https://drive.google.com/file/d/1BHL6o0dewqtyGyZBn-yMkCFrKUhc2a0m');
//let aluno5 = new Aluno('2º ano A', 'Thiago', 'Melo', 16, '2022ytrergf', 'https://drive.google.com/file/d/1yK1BWGSRxuHt4gP6mmYNOIRHs4plJ8gR');
//let aluno6 = new Aluno('2º ano A', 'Thayslane', 'Nascimento', 17, '2022fgsdfgtr', 'https://drive.google.com/file/d/1kQcfoPxzC3k0Jje8t6Qwo8we7JQhsdvR');
//let aluno7 = new Aluno('2º ano A', 'Robert', 'Silva', 19, '2022pukyjpl', 'https://drive.google.com/file/d/1drscdtgDQC-LFQVWkxioz8aJAPlELlcP');
//let aluno8 = new Aluno('2º ano A', 'Rebeca', 'Santos', 16, '2022qwerertuwri', 'https://drive.google.com/file/d/1vw8sfjAXTlZpfwTJNJSXJQd1sOgKiVb0');
//let aluno9 = new Aluno('2º ano A', 'Pedro', 'Castela', 17, '2022adcnmnc', 'https://drive.google.com/file/d/1cCtjjt4-ZEv-vj37DudZXx4WTvkBCmbs');
//let aluno10 = new Aluno('2º ano A', 'Paulo', 'Silva', 16, '2022mxmxm', 'https://drive.google.com/file/d/1RNj7Br60Yl7oqAK3Ypo2AQXU6vF4VDAY');

console.log(aluno1.getIdade());


// Crie um array, depois adicione os 3 alunos a esse array
let listaDeAlunos = [];
listaDeAlunos.push(aluno1);
listaDeAlunos.push(aluno2);
listaDeAlunos.push(aluno3);
listaDeAlunos.push(aluno4);
listaDeAlunos.push(aluno5);
listaDeAlunos.push(aluno6);
listaDeAlunos.push(aluno7);
listaDeAlunos.push(aluno8);
listaDeAlunos.push(aluno9);
listaDeAlunos.push(aluno10);


// Percorra o array e imprima os dados de cada 
// aluno no arquivo index.html








